-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: hotel-booking
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isAdmin` tinyint(1) DEFAULT '0',
  `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (6,'marat','marminkov@gmail.com','Israel',NULL,'Holon','+972544548101','$2b$10$EQxQ2D/M13DD31ecaEWy.eoxJHDZUWeW8wD6puodUQnQrHC61auYu',0,'2023-06-01 22:56:49','2023-06-01 22:56:49'),(19,'Vika','vika@tdnet.com','Israel',NULL,'Holon','adasdasdasd','$2b$10$WCLv0CtIXVN9JvycFm8iLOk7F5aJfsHp.r7pgKRkn5b.9UC5J7JcG',1,'2023-06-13 23:17:52','2023-06-13 23:18:52'),(20,'sad@gmail.com','sad@gmail.com','dsf',NULL,'dsf','dsf','$2b$10$q.9NDTI.N7sLjc752TWIDuZqHtVPtMpfzY7x7tWD5BEL2Ps.SNmPu',1,'2023-06-18 21:10:26','2023-06-18 21:10:26'),(22,'vika@tdnet.com','vika.galperina@tdnet.com','IsraelSZCz',NULL,'ZCXzCzC','zCzCzC','$2b$10$FZK63bEvxAccpCecn8.V/OOkdKvCpxnBNdiyMzDfmo5xZQ.nNTG2q',0,'2023-06-24 01:09:56','2023-06-24 01:09:56'),(25,'sdfsdfsdfsdf','dfgfdgfdg@tdnet.com','dsfdsfdsfdfs',NULL,'dsfsdfdsf','dsfsdfdsf','$2b$10$B5CD/vHg7cUUulbhGzZwTuQQJm9YaUzEi1nQELLVhFS7BtX7QRTWa',0,'2023-06-24 01:12:14','2023-06-24 01:12:14'),(28,'dsfsdfdsf','fghfghfgfghfgh@tdnet.com','dsfsdfsdfdsf',NULL,'sdfdsfdsf','fgdhgfhfghgfh','$2b$10$IevoAXi1NvH6wh1f9dyEuuGObK6kJwYbkF27bCvaUBH/3wJCIyZw2',0,'2023-06-24 01:14:50','2023-06-24 01:14:50'),(29,'dfgfdg','vifdgdfgka@tdnet.com','dfgdfg',NULL,'dfgdfg','dfgdfgdfgdfg','$2b$10$pF5ZUflXPCMU4cJumKNTbupkqjoxckVupECPgXGmnwq.MoAkNF4Ui',0,'2023-06-24 01:22:34','2023-06-24 01:22:34'),(30,'fdghgfh','vika@tdneghfghft.com','gfhgfh',NULL,'fghgfh','gfhfghgfh','$2b$10$RYHCSws9VwMtcr09A4ztlOe7KqHa90YaSshSMKN2ZdeaUpxR4ftwq',0,'2023-06-24 01:22:59','2023-06-24 01:22:59'),(33,'xsdfgfdcbh','vikgfhfghgfha@tdnet.com','gfhgfhgfhgfh',NULL,'gfhgfhgfh','gfhfghgfh','$2b$10$tPWlJUvVLFX5Lqypr9/IwuSPO9vrjTftD4waIcmL9oG/C85Fs66Ny',0,'2023-06-24 01:25:40','2023-06-24 01:25:40'),(34,'vika@tdnet.com','vxzczxcxzcika@tdnet.com','Israxzczxcxzcel',NULL,'gfhgfhgfh','+97254454xzczxczxcxzc8106','$2b$10$XaNc3IoccgMOZFcfgXimuuhHt.7wB6KQRlI5hVz4FGAAgashd6PQy',0,'2023-06-24 01:28:48','2023-06-24 01:28:48');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 17:11:56
