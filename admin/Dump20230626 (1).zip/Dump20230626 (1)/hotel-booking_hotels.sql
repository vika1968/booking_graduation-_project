-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: hotel-booking
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hotels`
--

DROP TABLE IF EXISTS `hotels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotels` (
  `hotelID` int NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `type` varchar(500) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `distance` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rating` decimal(3,1) DEFAULT NULL,
  `cheapestPrice` decimal(10,2) NOT NULL,
  `featured` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hotelID`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotels`
--

LOCK TABLES `hotels` WRITE;
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
INSERT INTO `hotels` VALUES (183,'Grand Hotel New York','hotel','New York','Elikton strt, 23','600','Grand Hotel','Located in New York, 600 metres from The High Line, 1 km from Penn Station and 1.1 km from Flatiron Building, 5 Star Luxury Apt In Chelsea New York provides accommodation with a balcony and free WiFi..',0.0,780.00,0),(184,'Life Hotel New York','hotel','New York','Empire State st.223','800','Life Hotel','Located between Broadway and 5th Avenue, Life Hotel is surrounded with dining options. Macy’s Herald Square is 483 metres from the property while the Empire State Building is 322 metres away.',0.0,670.00,0),(185,'Central London, Luxurious Studio','hotel','London','Byalik str, 26, London','2000','Luxurious Studio','Located in the centre of London, 700 metres from Paddington Station and 1.2 km from Madame Tussauds, Central London, Luxurious Studio offers free WiFi. New to Booking.com.Located in the centre of London, 700 metres from Paddington Station and 1.2 km from Madame Tussauds, Central London, Luxurious Studio offers free WiFi. New to Booking.com.Located in the centre of London, 700 metres from Paddington Station and 1.2 km from Madame Tussauds, Central London, Luxurious Studio offers free WiFi. New to Booking.com',0.0,590.00,0),(186,'Barceló Imagine','hotel','Barselona','Madrid Chamartín st 23','200','Barceló','Located 600 metres from Plaza Castilla, Barceló Imagine features avant-garde style, a rooftop terrace with outdoor pool and a garden. Madrid Chamartín Metro and Train Stations are 5 minutes’ walk away.  This concept hotel brings together all types of musical genres and features themed rooms exploring rock, jazz or flamenco. The modern, air-conditioned rooms come with a seating area, flat-screen satellite TV and tea and coffee maker. The private bathrooms include free toiletries and a hairdryer.  Barceló Imagine offers a gym and a massage room. There is a lobby bar that serves snacks and drinks and a Sky Lounge with views of Madrid that serves cocktails.  The hotel also offers 3 meeting rooms that can be joined to form a large and bright events room with direct access to a terrace.',0.0,1000.00,0);
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 17:11:56
