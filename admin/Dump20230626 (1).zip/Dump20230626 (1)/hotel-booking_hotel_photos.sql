-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: hotel-booking
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hotel_photos`
--

DROP TABLE IF EXISTS `hotel_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel_photos` (
  `photoID` int NOT NULL AUTO_INCREMENT,
  `hotelID` int DEFAULT NULL,
  `photo` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`photoID`),
  KEY `hotelID` (`hotelID`),
  CONSTRAINT `hotel_photos_ibfk_1` FOREIGN KEY (`hotelID`) REFERENCES `hotels` (`hotelID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_photos`
--

LOCK TABLES `hotel_photos` WRITE;
/*!40000 ALTER TABLE `hotel_photos` DISABLE KEYS */;
INSERT INTO `hotel_photos` VALUES (71,183,'photo-1611892440504-42a792e24d32.webp'),(72,183,'istockphoto-1406314006-2048x2048.jpg'),(73,183,'photo-1629140727571-9b5c6f6267b4.webp'),(74,183,'photo-1591088398332-8a7791972843.webp'),(75,184,'photo-1590490360182-c33d57733427.webp'),(76,184,'photo-1631049552057-403cdb8f0658.webp'),(77,184,'istockphoto-1390233984-2048x2048.jpg'),(78,184,'hotel-room-beautiful-orange-sofa-included-43642330.webp'),(79,184,'hotel-room-bright-modern-interior-condominium-37608904.webp'),(80,185,'luxuryhotelroom.webp'),(81,185,'istockphoto-1050564510-2048x2048.jpg'),(82,185,'hotel-room-4780421.webp'),(83,186,'istockphoto-1300135335-2048x2048.jpg'),(84,186,'hotel-room-beautiful-orange-sofa-included-43642330.webp'),(85,186,'istockphoto-1201397488-2048x2048.jpg'),(86,186,'hotel-room-bright-modern-interior-condominium-37608904.webp'),(87,186,'Hotel AtlanticОткроется в новом окне_Main.webp'),(88,186,'istockphoto-1370825295-2048x2048.jpg'),(89,186,'istockphoto-1400834458-2048x2048.jpg'),(90,186,'photo-1629140727571-9b5c6f6267b4.webp'),(91,183,'istockphoto-1392992509-2048x2048.jpg'),(92,183,'5-star-hotel-room-wallpaper-preview.jpg'),(93,184,'photo-1542314831-068cd1dbfeeb.webp'),(94,186,'photo-1579427421635-a0015b804b2e.webp'),(95,185,'photo-1580656155356-c0c1389c5cba.webp'),(96,185,'photo-1566073771259-6a8506099945.webp'),(97,185,'photo-1557499305-0af888c3d8ec.webp');
/*!40000 ALTER TABLE `hotel_photos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 17:11:56
