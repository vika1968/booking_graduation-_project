-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: hotel-booking
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `image_mapping`
--

DROP TABLE IF EXISTS `image_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `image_mapping` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image_path` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image_mapping`
--

LOCK TABLES `image_mapping` WRITE;
/*!40000 ALTER TABLE `image_mapping` DISABLE KEYS */;
INSERT INTO `image_mapping` VALUES (1,'https://images.unsplash.com/photo-1611892440504-42a792e24d32?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80','photo-1611892440504-42a792e24d32.webp'),(2,'https://media.istockphoto.com/id/1406314006/photo/modern-hotel-bedroom-interior.jpg?s=2048x2048&w=is&k=20&c=Ce8_PODdg15K2udTFdA-8hi3vZpISZZBqW4gyBKhgJI=','istockphoto-1406314006-2048x2048.jpg'),(3,'https://c4.wallpaperflare.com/wallpaper/947/345/226/inside-of-water-bungalow-four-seasons-maldives-white-fabric-sofa-set-black-wooden-coffee-maker-and-brown-and-black-wooden-dresser-wallpaper-preview.jpg','photo-1629140727571-9b5c6f6267b4.webp'),(4,'https://images.unsplash.com/photo-1591088398332-8a7791972843?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80','photo-1591088398332-8a7791972843.webp'),(5,'https://images.unsplash.com/photo-1590490360182-c33d57733427?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80','photo-1590490360182-c33d57733427.webp'),(6,'https://images.unsplash.com/photo-1631049552057-403cdb8f0658?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80','photo-1631049552057-403cdb8f0658.webp'),(7,'https://media.istockphoto.com/id/1390233984/photo/modern-luxury-bedroom.jpg?s=2048x2048&w=is&k=20&c=Qr6-TUnCMpsuArE5v8cOuumfxBR41IXi2ht5CW6OtXo=','istockphoto-1390233984-2048x2048.jpg'),(8,'https://thumbs.dreamstime.com/z/hotel-room-beautiful-orange-sofa-included-43642330.jpg','hotel-room-beautiful-orange-sofa-included-43642330.webp'),(9,'https://thumbs.dreamstime.com/z/hotel-room-bright-modern-interior-condominium-37608904.jpg','hotel-room-bright-modern-interior-condominium-37608904.webp'),(10,'https://robbreport.com/wp-content/uploads/2023/04/luxuryhotelroom.jpg?w=1000','hotel-room-4780421.webp'),(11,'https://thumbs.dreamstime.com/z/hotel-room-4780421.jpg','luxuryhotelroom.webp'),(12,'https://media.istockphoto.com/id/1300135335/photo/luxurious-bedroom-interior-at-nigh-with-messy-bed-leather-armchairs-closet-and-garden-view.jpg?s=2048x2048&w=is&k=20&c=l8PTezba-jSdx_JRiNKhZZN5NKJiP7R9d-uzYSRR2Is=','istockphoto-1300135335-2048x2048.jpg'),(13,'https://media.istockphoto.com/id/1201397488/photo/hotel-room-with-panoramic-view-of-the-mountains.jpg?s=2048x2048&w=is&k=20&c=fwKa8-VpWeSkA_oYwbw8IUQ6siGsSwNMlp5H6z9zfPU=','istockphoto-1201397488-2048x2048.jpg'),(14,'https://media.istockphoto.com/id/1050564510/photo/3d-rendering-beautiful-luxury-bedroom-suite-in-hotel-with-tv.jpg?s=2048x2048&w=is&k=20&c=K8hhGo82zGfHTIKUss-ZaGTvIo2LtNoovffJxmFhaTU=','istockphoto-1050564510-2048x2048.jpg'),(15,'https://media.istockphoto.com/id/1392992509/photo/wooden-tiny-house-interior-with-bed-furniture-and-triangular-window.jpg?s=2048x2048&w=is&k=20&c=PKNC1mtuULdhwDs9HLcG8dItobT8e9P8SliI4pbSomY=','istockphoto-1392992509-2048x2048.jpg'),(16,'https://c4.wallpaperflare.com/wallpaper/721/832/884/5-star-hotel-room-wallpaper-preview.jpg','5-star-hotel-room-wallpaper-preview.jpg'),(17,'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80','photo-1542314831-068cd1dbfeeb.webp'),(18,'https://images.unsplash.com/photo-1579427421635-a0015b804b2e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=735&q=80','photo-1579427421635-a0015b804b2e.webp'),(19,'https://images.unsplash.com/photo-1580656155356-c0c1389c5cba?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80','photo-1580656155356-c0c1389c5cba.webp'),(20,'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80','photo-1566073771259-6a8506099945.webp'),(21,'https://images.unsplash.com/photo-1557499305-0af888c3d8ec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80','photo-1557499305-0af888c3d8ec.webp');
/*!40000 ALTER TABLE `image_mapping` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-27 17:11:56
